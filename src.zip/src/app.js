const express = require('express');
const path = require('path');
const app = express();
const routes = require('./routes/index.js')
//const setDomain = require('express-set-domain')

//settings********************************
app.set('views', path.join(__dirname, 'src/views'))
app.set('port', process.env.PORT || 3000);
//app.use(setDomain('https://www.comunidad.escom.ipn.mx/museo/'));
//middlewares****************************


//routes******************************
app.use(routes);

//static files*************************

app.use(express.static(path.join(__dirname, './public')));

// comienza el app***********************

app.listen(3000, ()=> console.log('el servidor esta vivo'))